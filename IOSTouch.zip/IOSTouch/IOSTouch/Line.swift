//
//  Line.swift
//  IOSTouch
//
//  Created by Louis Nel.
//  Copyright © 2018 COMP2601. All rights reserved.
//

import Foundation
import CoreGraphics

struct Line {
    var begin = CGPoint.zero
    var end = CGPoint.zero
}
