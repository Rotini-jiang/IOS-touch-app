//

//  DrawView.swift
//  PhysicsSimulation
//
//  Created by Lilian Wang on 2018-04-01.
//  Copyright © 2018 COMP1601. All rights reserved.
//

//
//  DrawView.swift
//  IOSTouch
//
//  Created by Louis Nel.
//  Copyright © 2018 COMP2601. All rights reserved.
//


import UIKit
import Foundation


class DrawView: UIView {
    @IBInspectable var finishedLineColor: UIColor = UIColor.black {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var currentLineColor: UIColor = UIColor.red {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable var lineThickness: CGFloat = 10 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    let WORLD_WIDTH = 1000 //meters
    
    var timer :Timer!
    var timerIsRunning = false
    
    var boundingRect : CGRect?
    var worldRect : CGRect?
    let GRAPH_LINE_THICKNESS = CGFloat(1)
    
    
    var ball = Circle(centre: CGPoint(x: 60, y: 200),
                      velocity: CGPoint(x:0,y:0),
                      radius:CGFloat(10))
    
    var currentLine: Line?
    
    var finishedLines = [Line]();
    
    //    var locationX:Float
    //    var locationY:Float
    //    var V0:Float
    //    var Vx = V0
    //    var Vy:Float
    //
    
    
    
    //for debug
    //    var line1 = Line(begin: CGPoint(x:50,y:50), end: CGPoint(x:100,y:100))
    //    var line2 = Line(begin: CGPoint(x:50,y:100), end: CGPoint(x:100,y:300))
    
    
    var count = 0
    @objc func updateTimer(){
        count = (count + 1) % 1000
        if count != 0 {return}
        
        if let rect = boundingRect {
            ball.advanceInArea(area: rect)
            let line3 = Line(begin: ball.centre, end: ball.centre)
            strokeLine(line: line3)
            finishedLines.append(line3)
        }
        setNeedsDisplay();
    }
    
    func runTimer() {
        if timerIsRunning {return}
        //means 0.1 msec interval
        timer = Timer.scheduledTimer(timeInterval: -0.5,target: self,selector:(#selector(DrawView.updateTimer)),userInfo: nil,repeats: true)
        timerIsRunning = true
    }
    func strokeLine(line: Line){
        //Use BezierPath to draw lines
        let path = UIBezierPath();
        path.lineWidth = lineThickness;
        path.lineCapStyle = CGLineCap.round;
        path.move(to: line.begin);
        path.addLine(to: line.end);
        path.stroke(); //actually draw the path
    }
    func strokeLine(line: Line, thickness :CGFloat){
        //Use BezierPath to draw lines
        let path = UIBezierPath();
        path.lineCapStyle = CGLineCap.round;
        path.lineWidth = thickness
        
        path.move(to: line.begin);
        path.addLine(to: line.end);
        path.stroke(); //actually draw the path
    }
    
    func strokeCircle(circle: Circle){
        //Use BezierPath to draw circle
        let path = UIBezierPath(ovalIn: CGRect(x: circle.centre.x - circle.radius,
                                               y: circle.centre.y - circle.radius,
                                               width: circle.radius*2,
                                               height: circle.radius*2))
        path.lineWidth = 4;
        path.fill()
        path.stroke(); //actually draw the path
    }
    
    func initialize(rect: CGRect){
        
        boundingRect = rect
        if rect.width > rect.height {
            worldRect = CGRect(x:0,y:0,width:WORLD_WIDTH,height: WORLD_WIDTH*Int(rect.height)/Int(rect.width))
        }
        else {
            worldRect = CGRect(x:0,y:0,width:WORLD_WIDTH*Int(rect.height)/Int(rect.width),height: WORLD_WIDTH)
        }
        
        
    }
    
    func drawGraphLines(rect: CGRect){
        let numDivisions = 50
        for index in 0...numDivisions {
            if index % 5 == 0 {UIColor.black.setStroke()}
            else {UIColor.lightGray.setStroke()}
            
            var divWidth :Float = 0
            
            if rect.width > rect.height {
                divWidth = Float(rect.width)/Float(numDivisions)
                let verticalGraphLine = Line(begin: CGPoint(x:Int(divWidth*Float(index)),y:0),
                                             end: CGPoint(x:Int(divWidth*Float(index)),y:Int(rect.height)))
                
                strokeLine(line: verticalGraphLine, thickness: GRAPH_LINE_THICKNESS)
                
                if Float(index)*Float(divWidth) < Float(rect.height) {
                    let horizontalGraphLine = Line(begin: CGPoint(x:0,y:Int(rect.height) - Int(divWidth*Float(index))),
                                                   end: CGPoint(x:Int(rect.width),y:Int(rect.height) -  Int(divWidth*Float(index))))
                    strokeLine(line: horizontalGraphLine, thickness: GRAPH_LINE_THICKNESS)
                }
            }
            else {
                divWidth = Float(rect.height)/Float(numDivisions)
                
                let horizontalGraphLine = Line(begin: CGPoint(x:0,y:Int(divWidth*Float(index))),
                                               end: CGPoint(x:Int(rect.width),y:Int(divWidth*Float(index))))
                
                strokeLine(line: horizontalGraphLine, thickness: GRAPH_LINE_THICKNESS)
                
                if Float(index)*Float(divWidth) < Float(rect.width) {
                    let verticalGraphLine = Line(begin: CGPoint(x:Int(divWidth*Float(index)),y:0),
                                                 end: CGPoint(x:Int(divWidth*Float(index)),y:Int(rect.height)))
                    strokeLine(line: verticalGraphLine, thickness: GRAPH_LINE_THICKNESS)
                }
                
            }
            let labelOffset = 15 //to help centre label
            if index % 10 == 0 {drawText(text: String(20*index), location: CGPoint(x: Int(divWidth*Float(index)) - labelOffset, y: Int(rect.height) - 30))}
        }
    }
    
    func drawText(text: String, location :CGPoint){
        let label: NSString = text as NSString
        
        // set the text color to dark gray
        let fieldColor: UIColor = UIColor.darkGray
        
        // set the font to Helvetica Neue 18
        let fieldFont = UIFont(name: "Helvetica Neue", size: 18)
        
        // set the line spacing to 6
        let paraStyle = NSMutableParagraphStyle()
        paraStyle.lineSpacing = 6.0
        
        // set the Obliqueness to 0.1
        let skew = 0.0
        
        let attributes: NSDictionary = [
            NSAttributedStringKey.foregroundColor: fieldColor,
            NSAttributedStringKey.paragraphStyle: paraStyle,
            NSAttributedStringKey.obliqueness: skew,
            NSAttributedStringKey.font: fieldFont!
        ]
        
        label.draw(in: CGRect(x: location.x, y: location.y, width: 200, height: 30), withAttributes: attributes as? [NSAttributedStringKey : Any])
        
    }
    
    override func draw(_ rect: CGRect) {
        if !timerIsRunning {runTimer()}
        if boundingRect == nil {initialize(rect: rect)}
        //check for possible change in view rect
        if boundingRect!.width != rect.width || boundingRect!.height != rect.height {initialize(rect:rect)}
        drawGraphLines(rect: rect)
        
        UIColor.orange.setFill()
        // Specify a border (stroke) color.
        UIColor.blue.setStroke()
        
        strokeCircle(circle: ball)
        
        //draw the finished lines
        //UIColor.black.setStroke() //finished lines in black
        finishedLineColor.setStroke();
        for line in finishedLines{
            strokeLine(line: line, thickness: lineThickness);
        }
        
        //for debug
        //        strokeLine(line: line1, thickness: lineThickness);
        //        strokeLine(line: line3, thickness: lineThickness);
        
        //draw current line if it exists
        if let line = currentLine {
            //UIColor.red.setStroke(); //current line in red
            currentLineColor.setStroke();
            strokeLine(line: line, thickness: lineThickness);
            let baseLine = Line(begin: line.end, end: CGPoint(x: line.begin.x, y: line.end.y))
            UIColor.black.setStroke()
            strokeLine(line: baseLine, thickness: lineThickness)
            let xDist = line.begin.x - line.end.x
            let yDist = line.begin.y - line.end.y
            let length = CGFloat(sqrt((xDist * xDist) + (yDist * yDist)))
            let locLabel = String.localizedStringWithFormat("%.1f %@", length, "m/sec")
            let tanTheta = abs(yDist)/abs(xDist)
            let theta = atan(tanTheta)*180.0/3.14159 //angle in degrees
            let angleLabel = String.localizedStringWithFormat("%.1f %@", theta, "deg")
            drawText(text: locLabel, location: CGPoint(x: line.end.x, y: (line.begin.y + line.end.y)/2 - 10))
            drawText(text: angleLabel, location: CGPoint(x: line.end.x + 10, y: line.end.y))
        }
        //draw current line if it exists
        
        
        if rect.width > rect.height {
            
            drawText(text: "（\(String(format: "%.2f",ball.centre.x))，\(String(format: "%.2f",ball.centre.y))）pix", location: CGPoint(x:0,y:10));
            drawText(text: "（\(String(format: "%.2f",ball.centre.x * 1000/rect.width))，\(String(format: "%.2f",(rect.height-ball.centre.y) * 1000/rect.width)))）m", location: CGPoint(x:0,y:360));
            
        }else {
            drawText(text: "（\(String(format: "%.2f",ball.centre.x))，\(String(format: "%.2f",ball.centre.y))）pix", location: CGPoint(x:0,y:20));
            drawText(text: "（\(String(format: "%.2f",ball.centre.x * 1000/rect.height))，\(String(format: "%.2f",(rect.height-ball.centre.y ) * 1000/rect.height)))）m", location: CGPoint(x:0,y:680));
        }
    }
    
    var dragStart: CGPoint?
    var dragLocation : CGPoint?
    var locationDelta : CGPoint?
    
    //Override Touch Functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //runTimer()
        print(#function) //for debugging
        finishedLines = [Line]();//clean path line
        let touch = touches.first!; //get first touch event and unwrap optional
        let location = touch.location(in: self); //get location in view co-ordinates
        if ball.containsPoint(point: location){
            dragLocation = touch.location(in: self)
            dragStart = touch.location(in: self)
            print("HIT THE CIRCLE")
        }
        else{
            ball.centre = location;
            dragLocation = location;
            dragStart = location
            print("THE CIRCLE POSITIONED AT THE LOCATION")
        }
        currentLine = Line(begin: location, end: location);
        
        setNeedsDisplay(); //this view needs to be updated
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        print(#function) //for debugging
        let touch = touches.first!
        let location = touch.location(in: self);
        
        currentLine?.end = location
        setNeedsDisplay();
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print(#function) //for debugging
        if var line = currentLine {
            let touch = touches.first!
            let location = touch.location(in: self)
            line.end = location;
            if dragLocation != nil {
                let SCALE = CGFloat(4) //arbitrary scaling factor for now
                ball.velocity = CGPoint(x: (line.begin.x - line.end.x)/SCALE, y: (line.begin.y - line.end.y)/SCALE)
            }
            else {
                
            }
        }
        dragLocation = nil
        dragStart = nil
        currentLine = nil
        setNeedsDisplay()
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>?, with event: UIEvent?) {
        print(#function) //for debugging
        currentLine = nil
        dragLocation = nil
        setNeedsDisplay()
    }
}
