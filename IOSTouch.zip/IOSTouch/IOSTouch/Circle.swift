//
//  Circle.swift
//  IOSTouch
//
//  Created by Louis Nel on 2018-02-20.
//  Copyright © 2018 COMP2601. All rights reserved.
//

import Foundation
import CoreGraphics

struct Circle {
    var centre = CGPoint.zero
    var velocity = CGPoint.zero
    var radius: CGFloat = 40.0
    
    func distanceToPoint(point: CGPoint) -> CGFloat {
        let xDist = centre.x - point.x
        let yDist = centre.y - point.y
        return CGFloat(sqrt((xDist * xDist) + (yDist * yDist)))
    }
    
    func containsPoint(point:CGPoint) -> Bool {
        return distanceToPoint(point: point) <= radius
    }
    
    mutating func advanceInArea(area: CGRect){
        centre.x = centre.x + velocity.x
        centre.y = centre.y + velocity.y

        if centre.y + radius > area.height {
            velocity.y = 0
            velocity.x = 0}

        if velocity.x != 0 || velocity.y != 0{

        velocity.y = velocity.y + 9.81 //slow down with each advance
        }
    }
}
